<?php
  $hn = '127.0.0.1';
  $db = 'sdi1400058';
  $un = 'eam_user';
  $pw = 'pass'
?>
